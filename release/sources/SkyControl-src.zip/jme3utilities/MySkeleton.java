/*
 Copyright (c) 2013-2014, Stephen Gold
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:
 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright
 notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 * Stephen Gold's name may not be used to endorse or promote products
 derived from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL STEPHEN GOLD BE LIABLE FOR ANY
 DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package jme3utilities;

import com.jme3.animation.Bone;
import com.jme3.animation.Skeleton;
import com.jme3.animation.SkeletonControl;
import com.jme3.app.SimpleApplication;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import java.util.Collection;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import jme3utilities.debug.Validate;

/**
 * Utility methods for manipulating bones and skeletons. Aside from test cases,
 * all methods should be public and static.
 *
 * @author Stephen Gold <sgold@sonic.net>
 */
public class MySkeleton
        extends SimpleApplication {
    // *************************************************************************
    // constants

    /**
     * message logger for this class
     */
    final private static Logger logger =
            Logger.getLogger(MySkeleton.class.getName());
    // *************************************************************************
    // constructors

    /**
     * A private constructor to inhibit instantiation of this class.
     */
    private MySkeleton() {
    }
    // *************************************************************************
    // new methods exposed

    /**
     * Compute a specific angle of a named bone in an animated spatial.
     *
     * @param spatial animated spatial which contains the bone (not null)
     * @param boneName name of the bone to measure (not null)
     * @param axis which axis to measure (0 &rarr; X, 1 &rarr; Y, 2 &rarr; Z)
     * @return the rotation angle (in radians) or zero for unknown bone
     */
    public static float boneAngle(Spatial spatial, String boneName, int axis) {
        Validate.nonNull(spatial, "spatial");
        Validate.nonNull(boneName, "name");
        if (axis < 0 || axis > 2) {
            logger.log(Level.SEVERE, "axis={0}", axis);
            throw new IllegalArgumentException(
                    "axis should be between 0 and 2, inclusive");
        }

        Bone bone = getBone(spatial, boneName);
        if (bone == null) {
            return 0f;
        }
        Quaternion orientation = bone.getLocalRotation();
        float[] angles = orientation.toAngles(null);
        float angle = angles[axis];
        return angle;
    }

    /**
     * Access a named bone in an animated spatial.
     *
     * @param spatial animated spatial which contains the bone (not null)
     * @param boneName which bone to access (not null)
     * @return the pre-existing instance (or null if not found)
     */
    public static Bone getBone(Spatial spatial, String boneName) {
        Validate.nonNull(spatial, "spatial");
        Validate.nonNull(boneName, "name");

        Skeleton skeleton = getSkeleton(spatial);
        if (skeleton == null) {
            return null;
        }
        Bone bone = skeleton.getBone(boneName);
        return bone;
    }

    /**
     * Access the skeleton of an animated spatial.
     *
     * @param spatial animated spatial which contains the bone (not null)
     * @return the pre-existing instance (or null if not found)
     */
    public static Skeleton getSkeleton(Spatial spatial) {
        SkeletonControl control = spatial.getControl(SkeletonControl.class);
        if (control == null) {
            return null;
        }
        Skeleton skeleton = control.getSkeleton();
        return skeleton;
    }

    /**
     * List all bones in an animated spatial.
     *
     * @param spatial animated spatial which contains the bone (or null)
     * @return a new collection in lexicographic order (may be empty)
     */
    public static Collection<String> listBones(Spatial spatial) {
        Collection<String> names = new TreeSet<>();
        if (spatial == null) {
            return names;
        }
        Skeleton skeleton = getSkeleton(spatial);
        if (skeleton != null) {
            int boneCount = skeleton.getBoneCount();
            for (int boneIndex = 0; boneIndex < boneCount; boneIndex++) {
                Bone bone = skeleton.getBone(boneIndex);
                String name = bone.getName();
                names.add(name);
            }
        }
        return names;
    }

    /**
     * Convert a location in a bone's local space to a model location vector.
     *
     * @param bone (not null)
     * @param x displacement along the bone's X-axis
     * @param y displacement along the bone's Y-axis
     * @param z displacement along the bone's Z-axis
     * @return a new vector
     *
     */
    public static Vector3f modelLocation(Bone bone, float x, float y, float z) {
        Vector3f tail = bone.getModelSpacePosition();
        Vector3f scale = bone.getModelSpaceScale();
        Vector3f local = new Vector3f(x, y, z).multLocal(scale);
        local.addLocal(tail);
        return local;
    }

    /**
     * Adjust one rotation angle in the bind pose of an animated spatial.
     *
     * @param spatial animated spatial which contains the bone (not null)
     * @param boneName name of the bone to adjust (not null)
     * @param axis which axis to adjust (0 &rarr; x, 1 &rarr; y, 2 &rarr; z)
     * @param newAngle new rotation angle (in radians)
     */
    public static void setBoneAngle(Spatial spatial, String boneName, int axis,
            float newAngle) {
        Validate.nonNull(spatial, "spatial");
        Validate.nonNull(boneName, "name");
        if (axis < 0 || axis > 2) {
            logger.log(Level.SEVERE, "axis={0}", axis);
            throw new IllegalArgumentException(
                    "axis should be between 0 and 2, inclusive");
        }

        Bone bone = getBone(spatial, boneName);
        if (bone == null) {
            return;
        }
        Misc.setAngle(bone, axis, newAngle);
        getSkeleton(spatial).updateWorldVectors();
    }

    /**
     * Compute the world location of (the tail of) a named bone.
     *
     * @param spatial animated spatial which contains the bone (not null)
     * @param boneName (not null)
     * @return a new vector
     */
    public static Vector3f worldLocation(Spatial spatial, String boneName) {
        Validate.nonNull(spatial, "spatial");
        Validate.nonNull(boneName, "name");

        Bone bone = getBone(spatial, boneName);
        Vector3f local = bone.getModelSpacePosition();
        Vector3f world = spatial.localToWorld(local, null);
        return world;
    }

    /**
     * Compute the world orientation of a named bone.
     *
     * @param spatial animated spatial which contains the bone (not null)
     * @param boneName (not null)
     * @return a new vector
     */
    public static Quaternion worldOrientation(Spatial spatial,
            String boneName) {
        Validate.nonNull(spatial, "spatial");
        Validate.nonNull(boneName, "name");

        Bone bone = getBone(spatial, boneName);

        Quaternion local = bone.getModelSpaceRotation();
        Quaternion wbi = bone.getWorldBindInverseRotation();
        Quaternion product = local.mult(wbi);

        Quaternion modelOrientation = spatial.getWorldRotation();
        Quaternion result = modelOrientation.mult(product);
        result.normalizeLocal();

        return result;
    }
    // *************************************************************************
    // test cases

    /**
     * Simple application to test the MySkeleton class.
     *
     * @param ignored
     */
    public static void main(String[] ignored) {
        Misc.setLoggingLevels(Level.SEVERE);
        MySkeleton application = new MySkeleton();
        application.setShowSettings(false);
        application.start();
    }

    @Override
    public void simpleInitApp() {
        logger.setLevel(Level.INFO);
        System.out.print("Test results for class MySkeleton:\n\n");

        String modelPath = "Models/Oto/Oto.mesh.xml";
        Node node = (Node) assetManager.loadModel(modelPath);
        rootNode.attachChild(node);

        String bone = "uparm.right";
        for (int axis = 0; axis < 3; axis++) {
            float angle = 0.2f + 0.1f * axis;
            System.out.printf("angle = %s%n", angle);
            setBoneAngle(node, bone, axis, angle);
            float angle2 = boneAngle(node, bone, axis);
            System.out.printf("angle2 = %s%n", angle2);
        }

        stop();
    }
}